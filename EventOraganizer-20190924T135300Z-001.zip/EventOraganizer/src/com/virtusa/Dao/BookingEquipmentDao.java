package com.virtusa.Dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.virtusa.Servlet.Userlogin;
import com.virtusa.bean.EquipBean;
public class BookingEquipmentDao {
	static final Logger logger = Logger.getLogger(BookingEquipmentDao.class);
	
	 public static Connection getConnection(){ 
		 PropertyConfigurator.configure("C:\\Users\\bhanu_000\\Desktop\\praticeprogs\\EventOraganizerHtml\\src\\log4j.properties");
	        Connection con=null;  
	        try{  
	            Class.forName("oracle.jdbc.driver.OracleDriver");  
	            con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","kavitha");  
	           
	        }catch(Exception e)
	       {
	  logger.error(e);
	    }  
	        return con;  
	    }  
	    public static int save(EquipBean e){  
	        int status=0;  
	        try{  
	            Connection con=BookingEquipmentDao.getConnection();  
	            PreparedStatement ps=con.prepareStatement("insert into bookEquipment(equipId,equipName,equipCost) values (?,?,?)");  
	           
	            ps.setInt(1,e.getEquipId());  
	            ps.setString(2,e.getEquipName());  
	            ps.setInt(3,e.getEquipCost());  
	            
	            
	            status=ps.executeUpdate();
	            
	            con.close();  
	        }catch(Exception ex){
	        	ex.printStackTrace();}  
	          
	        return status;  
	    }
	  
	    
	    public static EquipBean getEquipById(int equipId){  
	    	EquipBean e=new EquipBean();  
	           
	         try{  
	             Connection con=BookingEquipmentDao.getConnection();  
	             PreparedStatement ps=con.prepareStatement("select * from  equipManagement where equipId=?");  
	             ps.setInt(1,equipId);  
	             ResultSet rs=ps.executeQuery();  
	             if(rs.next()){  
	                 e.setEquipId(rs.getInt(1));  
	                 e.setEquipName(rs.getString(2));  
	                 e.setEquipCost(rs.getInt(3));  
	                 
	                   
	             }  
	             con.close();  
	         }catch(Exception ex){
	         	ex.printStackTrace();}  
	           
	         return e;  
	     }  
	  
	    
	    
	    
}
