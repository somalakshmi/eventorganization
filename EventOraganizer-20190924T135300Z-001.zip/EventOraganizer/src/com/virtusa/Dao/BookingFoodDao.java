package com.virtusa.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.virtusa.bean.FoodBean;
public class BookingFoodDao {
	static final Logger logger = Logger.getLogger( BookingFoodDao.class);
	
	 public static Connection getConnection(){  
		 PropertyConfigurator.configure("C:\\Users\\bhanu_000\\Desktop\\praticeprogs\\EventOraganizerHtml\\src\\log4j.properties");
	        Connection con=null;  
	        try{  
	            Class.forName("oracle.jdbc.driver.OracleDriver");  
	            con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","kavitha");  
	          
	        }catch(Exception e)
	       {
	   logger.error(e);
	    }  
	        return con;  
	    }  
	    public static int save(FoodBean e){  
	        int status=0;  
	        try{  
	            Connection con=BookingFoodDao.getConnection();  
	            PreparedStatement ps=con.prepareStatement("insert into bookfood(foodId,foodName,foodCost) values (?,?,?)");  
	            
	            ps.setInt(1,getFoodById());  
	            ps.setString(2,e.getFoodName());  
	            ps.setInt(3,e.getFoodCost());  
	           
	            
	            status=ps.executeUpdate();
	            
	            con.close();  
	        }catch(Exception ex){
	        	ex.printStackTrace();}  
	          
	        return status;  
	    }
	    public static int getFoodById() {
	    	int id=0;
	    
	    	try{  
	            Connection con=BookingFoodDao.getConnection(); 
	            PreparedStatement ps=con.prepareStatement("select count(*) from bookfood");
	            ResultSet rs=ps.executeQuery();
	            if(rs.next())
	            {
	            	id=rs.getInt(1)+1;
	            }else{
	            	id=id+1;
	            }}catch(Exception e1) {
	            	e1.printStackTrace();
	            }
	    	return id;
	    	}
	    public static FoodBean getFoodById(int foodId){  
	    	FoodBean e=new FoodBean();  
		          
		        try{  
		            Connection con=FoodDao.getConnection();  
		            PreparedStatement ps=con.prepareStatement("select * from foodManagement where foodId=?");  
		            ps.setInt(1,foodId);  
		            ResultSet rs=ps.executeQuery();  
		            if(rs.next()){  
		                e.setFoodId(rs.getInt(1));  
		                e.setFoodName(rs.getString(2));  
		                e.setFoodCost(rs.getInt(3));  
		               
		                  
		            }  
		            con.close();  
		        }catch(Exception ex){
		        	ex.printStackTrace();
		        	} return e; 
		        
	    }
	    

}




	    

