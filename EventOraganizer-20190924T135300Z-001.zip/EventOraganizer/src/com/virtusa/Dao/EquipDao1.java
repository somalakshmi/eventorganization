package com.virtusa.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.virtusa.bean.EquipBean;
public class EquipDao1 {
	static final Logger logger = Logger.getLogger(EquipDao1.class);
public static Connection getConnection(){  
	PropertyConfigurator.configure("C:\\Users\\bhanu_000\\Desktop\\praticeprogs\\EventOraganizerHtml\\src\\log4j.properties");
       Connection con=null;  
       try{  
           Class.forName("oracle.jdbc.driver.OracleDriver");  
           con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","kavitha");  
       }catch(Exception e)
      {
  logger.error(e);
   }  
       return con;  
   }  
public static int save(EquipBean e){  
       int status=0;  
       try{  
       
           Connection con=EquipDao1.getConnection();
          
           PreparedStatement ps=con.prepareStatement(
        "insert into Equipmanagement(equipId ,equipName,equipCost) values(?,?,?)");  
       
           ps.setInt(1,e.getEquipId());  
           ps.setString(2,e.getEquipName());  
           ps.setInt(3,e.getEquipCost());  
           
             
           status=ps.executeUpdate();  
             
           con.close();  
       }catch(Exception ex){
        ex.printStackTrace();}  
         
       return status;  
   }  

public static int update(EquipBean  e1){  
    int status=0;  
    try{  
        Connection con=EquipDao1.getConnection();  

        PreparedStatement ps=con.prepareStatement("update Equipmanagement set equipName=?, equipCost=? where equipId=?");  
        
        ps.setString(1,e1.getEquipName());  
        ps.setInt(2,e1.getEquipCost());  
        ps.setInt(3, e1.getEquipId());
       
        status=ps.executeUpdate();  
        
        con.close();  
    }catch(Exception ex){
    	ex.printStackTrace();}  
      
    return status;  
}  

public static int delete(int equipId){  
       int status=0;  
       try{  
           Connection con=EquipDao1.getConnection();  
           PreparedStatement ps=con.prepareStatement("delete from Equipmanagement where equipId=?");  
           ps.setInt(1,equipId);  
           status=ps.executeUpdate();  
             
           con.close();  
       }catch(Exception e){
     e.printStackTrace();
      }  
         
       return status;  
   }  
public static EquipBean getequipById(int equipId){  
      EquipBean e=new EquipBean();  
         
       try{  
           Connection con=EquipDao1.getConnection();  
           PreparedStatement ps=con.prepareStatement("select * from Equipmanagement where equipId=?");  
           ps.setInt(1,equipId);  
           ResultSet rs=ps.executeQuery();  
           if(rs.next()){  
               e.setEquipId(rs.getInt(1));  
               e.setEquipName(rs.getString(2));  
               e.setEquipCost(rs.getInt(3));  
             
           }  
           con.close();  
       }catch(Exception ex){
        ex.printStackTrace();}  
         
       return e;  
   }  
public static List<EquipBean> getAllEquipments(){  
       List<EquipBean> list=new ArrayList<EquipBean>();  
         
       try{  
           Connection con=EquipDao1.getConnection();  
           PreparedStatement ps=con.prepareStatement("select * from Equipmanagement");  
           ResultSet rs=ps.executeQuery();  
           while(rs.next()){  
            EquipBean e=new EquipBean();  
               e.setEquipId(rs.getInt(1));  
               e.setEquipName(rs.getString(2));  
               e.setEquipCost(rs.getInt(3));  
                 
               list.add(e);  
           }  
           con.close();  
       }catch(Exception e){e.printStackTrace();}  
         
       return list;  
   }  
 
}