package com.virtusa.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.virtusa.bean.FoodBean;

public class ViewFoodDao {
	public static Connection getConnection(){  
        Connection con=null;  
        try{  
            Class.forName("oracle.jdbc.driver.OracleDriver");  
            con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","kavitha");  
        }catch(Exception e)
       {
   System.out.println(e);
    }  
        return con;  
    }  
	public static List<FoodBean> getAllFood(){  
        List<FoodBean> list=new ArrayList<FoodBean>();  
          
        try{  
            Connection con=FoodDao.getConnection();  
            PreparedStatement ps=con.prepareStatement("select * from foodmanagement");  
            ResultSet rs=ps.executeQuery();  
            while(rs.next()){  
               FoodBean e=new FoodBean();  
                e.setFoodId(rs.getInt(1));  
                e.setFoodName(rs.getString(2));  
                e.setFoodCost(rs.getInt(3));  
                   
                list.add(e);  
            }  
            con.close();  
        }catch(Exception e){e.printStackTrace();}  
          
        return list;  
    }  
}
