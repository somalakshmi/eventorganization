package com.virtusa.Service;

import java.util.List;

import com.virtusa.Dao.FoodDao;
import com.virtusa.bean.FoodBean;

public class FoodService {
	//FoodDao fooddao=new FoodDao();

	public int saveFood(FoodBean e) {
		// TODO Auto-generated method stub
		int s=FoodDao.save(e);
		return s;
	}

	public List<FoodBean> viewFood() {
		// TODO Auto-generated method stub
		List<FoodBean> list=FoodDao.getAllFood();
		
		return list;
	}

	public FoodBean editFood1(int id) {
		// TODO Auto-generated method stub
		FoodBean e=FoodDao.getFoodById(id);
		return e;
	}

	public int editFood2(FoodBean e) {
		// TODO Auto-generated method stub
		int status=FoodDao.update(e);  
		return status;
	}

	public void deleteFood(int FoodId) {
		// TODO Auto-generated method stub
		FoodDao.delete(FoodId);
		
	}


}
