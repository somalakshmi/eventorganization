package com.virtusa.Servlet;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.virtusa.bean.*;
import com.virtusa.Dao.*;
import java.io.PrintWriter;  
@WebServlet("/BookingFood1")  
public class  BookingFood1 extends HttpServlet {  
    protected void doPost(HttpServletRequest request, HttpServletResponse response)   
          throws ServletException, IOException {  
        response.setContentType("text/html");  
        PrintWriter out=response.getWriter();  
          
        String sid=request.getParameter("foodId");  
        int id=Integer.parseInt(sid);  
        String name=request.getParameter("foodName");  
        String scost=request.getParameter("foodCost"); 
        int cost=Integer.parseInt(scost); 
        
        FoodBean e=new FoodBean();  
        e.setFoodId(id);  
        e.setFoodName(name);  
        e.setFoodCost(cost);  
        
         
          
        int status=BookingFoodDao.save(e);  
        if(status>0){  

        	  out.println(" record  booked"); 
        }else{  
            out.println("Sorry! unable to book record");  
        }  
          
        out.close();  
    }  
  
}  
