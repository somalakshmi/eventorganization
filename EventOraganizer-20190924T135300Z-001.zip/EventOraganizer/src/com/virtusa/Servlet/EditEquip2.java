package com.virtusa.Servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.virtusa.bean.EquipBean;
import com.virtusa.Service.EquipService;
import java.io.PrintWriter;  
@WebServlet("/EditEquip2")  
public class EditEquip2 extends HttpServlet {  
    protected void doPost(HttpServletRequest request, HttpServletResponse response)  throws ServletException, IOException {  
        response.setContentType("text/html");  
        PrintWriter out=response.getWriter();  
         
        String sid=request.getParameter("equipId");  
        int id=Integer.parseInt(sid);  
        String name=request.getParameter("equipName");  
       String scost=request.getParameter("equipCost");
        int cost=Integer.parseInt(scost);
       
      EquipBean e=new EquipBean();  
        e.setEquipId(id);  
        e.setEquipName(name);  
        e.setEquipCost(cost);  
       
         

        EquipService ob=new EquipService();
        int status=ob.editEquip2(e);
        if(status>0){  
            response.sendRedirect("ViewEquip");  
        }else{  
            out.println("Sorry! unable to update record");  
        }  
         
        out.close();  
    }  
 
}  