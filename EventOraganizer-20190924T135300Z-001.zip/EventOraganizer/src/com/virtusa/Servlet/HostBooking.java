package com.virtusa.Servlet;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.virtusa.Dao.ViewVenueDao;
import com.virtusa.bean.VenueBean;
@WebServlet("/HostBooking")
public class HostBooking extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		out.println("<h1>venues  List</h1>");
		List<VenueBean> list=ViewVenueDao.getAllVenues();
		
		out.print("<table border='1' width='100%'");
		out.print("<tr><th>Id</th><th>venueName</th><th>venuecost</th><th>venuecontact</th><th>Book</th>");
		
		for(VenueBean e:list){
			out.print("<tr><td>"+e.getVenueId()+"</td><td>"+e.getVenueName()+"</td><td>"+e.getVenueCost()+"</td><td>"+e.getVenueContact()+"</td></td><td><a href='BookingServlet?id="+e.getVenueId()+"'>BookVenue</a></td></tr>");
		}
		out.print("</table>");
		
		
		out.close();
	}
}
		
		