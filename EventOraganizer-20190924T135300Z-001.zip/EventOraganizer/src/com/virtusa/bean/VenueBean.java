package com.virtusa.bean;
public class VenueBean  {
private int venueId;
private String venueName;
private int venueCost;
private int venueContact;
public int getVenueId() {
	return venueId;
}
public void setVenueId(int venueId) {
	this.venueId = venueId;
}
public String getVenueName() {
	return venueName;
}
public void setVenueName(String venueName) {
	this.venueName = venueName;
}
public int getVenueCost() {
	return venueCost;
}
public void setVenueCost(int venueCost) {
	this.venueCost = venueCost;
}
public int getVenueContact() {
	return venueContact;
}
public void setVenueContact(int venueContact) {
	this.venueContact = venueContact;
}
@Override
public String toString() {
	return "VenueBean [venueId=" + venueId + ", venueName=" + venueName + ", venueCost=" + venueCost + ", venueContact="
			+ venueContact + ", getVenueId()=" + getVenueId() + ", getVenueName()=" + getVenueName()
			+ ", getVenueCost()=" + getVenueCost() + ", getVenueContact()=" + getVenueContact() + ", getClass()="
			+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
}

}